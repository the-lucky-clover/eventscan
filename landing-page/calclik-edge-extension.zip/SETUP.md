# CalClik Extension - Quick Setup Guide

## Installation Steps

1. **Load the Extension**
   - Open Chrome/Brave and go to `chrome://extensions/`
   - Enable "Developer mode" (toggle in top right)
   - Click "Load unpacked"
   - Select the `calclik-chrome-extension` folder

2. **Enable File Access (Required for test-page.html)**
   - On the extensions page, find "CalClik - Smart Event Scanner"
   - Click the "Details" button
   - Scroll down to "Allow access to file URLs"
   - Toggle it ON

3. **Setup macOS Reminders (Optional)**

   macOS Reminders integration requires a native messaging host:

   a. **Copy Extension ID**
      - On `chrome://extensions/`, find your CalClik extension
      - Copy the Extension ID (e.g., `abcdefghijklmnopqrstuvwxyz123456`)

   b. **Update Host Configuration**
      - Open `host/com.calendare.reminderhost.json`
      - Replace `YOUR_EXTENSION_ID_HERE` with your actual extension ID
      - Update the `path` field to the absolute path of `host.js`:

        ```json
        "/absolute/path/to/calclik-chrome-extension/host/host.js"
        ```

   c. **Install Native Host**
      - Create directory: `mkdir -p ~/Library/Application\ Support/Google/Chrome/NativeMessagingHosts/`
      - Copy the JSON file:

        ```bash
        cp host/com.calendare.reminderhost.json ~/Library/Application\ Support/Google/Chrome/NativeMessagingHosts/
        ```

      - Make host.js executable: `chmod +x host/host.js`
      - Ensure Node.js is installed: `node --version`

   d. **Test It**
      - Reload the CalClik extension
      - Scan a page with events
      - Click "macOS Reminders" button on any event
      - Check your Reminders app for the new reminder

4. **Test the Extension**

   **Option A: Use Local Test File**

   - Drag `test-page.html` into Chrome to open it
   - Click the CalClik extension icon in your toolbar
   - Extension automatically scans and displays 5 events
   - Click any calendar button to add events

   **Option B: Use Live Websites**

   - Visit any event website (Eventbrite, Meetup, conference sites)
   - Click the CalClik extension icon
   - Scan the page for events

## Troubleshooting

### "File access not enabled" Error

- Go to `chrome://extensions/`
- Click "Details" on CalClik
- Enable "Allow access to file URLs"
- Reload the test-page.html

### "No events found" Message

- Make sure the page has dates and times in the text
- Try a different page with event information
- Check the browser console (F12) for debug messages

### Extension Icon Not Appearing

- Pin the extension: Click the puzzle icon → Pin CalClik
- Refresh the page after loading the extension

## Development

To see debug logs:

- **Popup logs**: Right-click popup → Inspect
- **Background logs**: Go to `chrome://extensions/` → CalClik → "service worker" link
- **Content script logs**: Open page → F12 Console

## Support

Visit calclik.app for more information and support.
